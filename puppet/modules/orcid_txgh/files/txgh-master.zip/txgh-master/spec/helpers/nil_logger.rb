class NilLogger
  def info(*args)
  end

  def warn(*args)
  end

  def error(*args)
  end
end
