$:.unshift File::dirname(__FILE__)
$:.unshift "#{File::dirname(__FILE__)}/lib"
